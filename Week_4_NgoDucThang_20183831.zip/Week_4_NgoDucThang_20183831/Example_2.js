//Ngô Đức Thắng - 20183831
let str = "I love abc abc you a  bc and  abc our son";
let sub = "abc";
console.log(str.split(sub).length - 1);
