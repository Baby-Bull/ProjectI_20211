//Ngô Đức Thắng - 20183831
var string = "Ngo Duc Thang";
console.log(string.split(" ")[0]);