//Ngô Đức Thắng - 20183831
var string = "100100001111001010";
console.log(string);
console.log(string.replace(/\d/g,x=>x^1));