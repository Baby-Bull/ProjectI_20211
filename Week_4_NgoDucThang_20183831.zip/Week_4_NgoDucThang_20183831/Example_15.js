//Ngô Đức Thắng 20183831 
var s1 = "day la chuoi + ban dau";
var s2 = " day la chuoi can them ";
console.log(s1.replace("+", s2));