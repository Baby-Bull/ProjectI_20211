//Ngô Đức Thắng - 20183831
var string = "day la chuoi ban dau";
console.log(string.split("").reverse().join(""));