//Ngô Đức Thắng 20183831 
var s1 = "day la chuoi 1";
var s2 = "chuoi";
(s1.includes(s2)) ? console.log("s2 la con chuoi s1") : console.log("s2 khong la con chuoi s1");