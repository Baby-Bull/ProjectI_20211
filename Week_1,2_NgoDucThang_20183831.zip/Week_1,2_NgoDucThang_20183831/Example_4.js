for(let i = 0; i< 100; i++){
    (i%3==0 && i%7==0) && console.log(i);
}