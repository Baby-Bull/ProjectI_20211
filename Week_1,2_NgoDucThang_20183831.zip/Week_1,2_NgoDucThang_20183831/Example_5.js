for(let i = 1000; i< 2000; i++){
    (i%3==0 && i%5==0 && i%7==0) && console.log(i);
}