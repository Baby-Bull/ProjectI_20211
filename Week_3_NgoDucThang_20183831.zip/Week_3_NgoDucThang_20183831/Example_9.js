//Ngô Đức Thắng - 2018381
var array = [5, 343, 32, 234, 5, 0, 40, 34, 0, 0, 23];
for (let i = 0; i < array.length; i++) {
    if(array[i]!=0) console.log(array[i]+",");
}