//Ngô Đức Thắng - 2018381
var array = [5,343,32,234,5,46,4,34,456,34,23];
console.log("so nho hon tat ca cac so trong day la : " + (Math.min.apply(Math,array)-1));